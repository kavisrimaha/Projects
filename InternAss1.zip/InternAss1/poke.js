const gallery = document.getElementById("pokemonGallery");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");

let allPokemon = [];

// Fetch 150 Pokémon on load
async function loadAllPokemon() {
    try {
        const response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=150");
        const data = await response.json();

        const fetches = data.results.map(pokemon => fetch(pokemon.url).then(res => res.json()));
        allPokemon = await Promise.all(fetches);

        renderPokemon(allPokemon);
    } catch (error) {
        console.error("Error loading Pokémon:", error);
    }
}

// Render Pokémon list
function renderPokemon(pokemonList) {
    gallery.innerHTML = "";

    pokemonList.forEach(p => {
        const card = document.createElement("div");
        card.className = "pokemon-card";

        card.innerHTML = `
            <img src="${p.sprites.front_default}" alt="${p.name}">
            <h3>${capitalize(p.name)}</h3>
            <p><strong>Type:</strong> ${p.types.map(t => t.type.name).join(", ")}</p>
            <p><strong>Base Exp:</strong> ${p.base_experience}</p>
        `;

        gallery.appendChild(card);
    });
}

// Capitalize name
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Filter function
searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    const filtered = allPokemon.filter(p => p.name.includes(query));
    renderPokemon(filtered);
});

// Sort function
sortSelect.addEventListener("change", () => {
    const value = sortSelect.value;
    let sorted = [...allPokemon];

    if (value === "name") {
        sorted.sort((a, b) => a.name.localeCompare(b.name));
    } else if (value === "baseExp") {
        sorted.sort((a, b) => b.base_experience - a.base_experience);
    }

    renderPokemon(sorted);
});

// Initial load
loadAllPokemon();

<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Session_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function save_session($data) {
        return $this->db->insert('sessions', $data);
    }
    // application/models/Session_model.php
    public function get_all_sessions() {
        $this->db->order_by('date', 'DESC');
        return $this->db->get('sessions')->result_array();
    }

    // Add other methods as needed (get_sessions, etc.)
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function register_user($data) {
    // Add debugging
    log_message('debug', 'Attempting to register user: '.print_r($data, true));
    
    $user_data = [
        'username' => $data['username'],
        'password' => password_hash($data['password'], PASSWORD_DEFAULT),
        'role' => 'user',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $result = $this->db->insert('users', $user_data);
    
    if (!$result) {
        log_message('error', 'Database error: '.print_r($this->db->error(), true));
        return false;
    }
    return $result;
}

    public function check_username_exists($username) {
        return $this->db->where('username', $username)
                       ->count_all_results('users') > 0;
    }

    public function verify_user($username, $password) {
        $user = $this->db->where('username', $username)
                        ->get('users')
                        ->row_array();
        
        return ($user && password_verify($password, $user['password'])) ? $user : false;
    }
    
    public function get_all_users() {
    return $this->db->get('users')->result_array();
}

public function get_paginated_users($limit, $offset) {
    $this->db->order_by('created_at', 'DESC');
    $this->db->limit($limit, $offset);
    return $this->db->get('users')->result_array();
}

public function count_users() {
    return $this->db->count_all('users');
}

public function get_user($id) {
    return $this->db->where('id', $id)->get('users')->row_array();
}

public function update_user($id, $data) {
    $this->db->where('id', $id);
    return $this->db->update('users', $data);
}

public function delete_user($id) {
    $this->db->where('id', $id);
    return $this->db->delete('users');
}
    
}
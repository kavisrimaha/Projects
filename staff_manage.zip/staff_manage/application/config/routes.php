<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Admin Routes
$route['default_controller'] = 'admin_login';
$route['admin'] = 'admin_login';
$route['login'] = 'admin_login';
$route['register'] = 'admin_register';
$route['admin/register/submit'] = 'admin_register/submit';
$route['admin/logout'] = 'admin_login/logout';

// Session routes
$route['sessions'] = 'admin/sessions';
$route['admin/save_session'] = 'admin/save_session';
$route['admin/tracker'] = 'admin/tracker';

// User management routes
$route['users'] = 'admin/users';
$route['admin/users/add'] = 'admin/add_user';
$route['admin/users/edit/(:num)'] = 'admin/edit_user/$1';
$route['admin/users/delete/(:num)'] = 'admin/delete_user/$1';

// User authentication
$route['user/authenticate'] = 'user/authenticate';
$route['user/tracker'] = 'admin/tracker';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
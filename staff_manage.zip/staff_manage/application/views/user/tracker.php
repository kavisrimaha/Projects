<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Session Tracker | CodeIgniter</title>
    <style>
        /* Base Styles - Matching Your Theme */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #FFCCB8;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #A05535;
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #A05535;
            padding-bottom: 10px;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        input[type="file"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }

        input:focus,
        textarea:focus,
        select:focus {
            border-color: #A05535;
            outline: none;
            box-shadow: 0 0 0 2px rgba(160, 85, 53, 0.2);
        }

        /* File Input Styling */
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }

        .file-input-button {
            background-color: #A05535;
            color: white;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            display: block;
        }

        .file-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* Button Styles */
        .submit-btn {
            background-color: #A05535;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #804225;
        }

        /* Grid Layout */
        .form-row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }

        .form-col {
            flex: 1;
            padding: 0 10px;
            min-width: 250px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-col {
                flex: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Session Tracker</h1>
        
        <?php if($this->session->flashdata('success')): ?>
            <div class="success-message" style="color: #388E3C; background-color: #E8F5E9; padding: 10px; border-radius: 4px; margin-bottom: 20px; border-left: 4px solid #388E3C;">
                <?= $this->session->flashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <?= form_open_multipart('admin/save_session') ?>
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label for="hub_name">Hub Name</label>
                        <input type="text" name="hub_name" id="hub_name" required>
                    </div>
                </div>
                
                <div class="form-col">
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" id="date" required>
                    </div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label for="session_number">Session Number</label>
                        <input type="number" name="session_number" id="session_number" required>
                    </div>
                </div>
                
                <div class="form-col">
                    <div class="form-group">
                        <label for="sessions_taken">No. of Sessions Taken</label>
                        <input type="number" name="sessions_taken" id="sessions_taken" required>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="expense_amount">Expense Amount (₹)</label>
                <input type="number" name="expense_amount" id="expense_amount" step="0.01" required>
            </div>
            
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label for="geo_tag">Geo Tag Photo</label>
                        <div class="file-input-wrapper">
                            <div class="file-input-button">Choose Photo</div>
                            <input type="file" name="geo_tag" id="geo_tag" accept="image/*" class="file-input" required>
                        </div>
                    </div>
                </div>
                
                <div class="form-col">
                    <div class="form-group">
                        <label for="session_video">5 mins Video</label>
                        <div class="file-input-wrapper">
                            <div class="file-input-button">Choose Video</div>
                            <input type="file" name="session_video" id="session_video" accept="video/*" class="file-input" required>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label for="students_present">No. of Students Present</label>
                        <input type="number" name="students_present" id="students_present" required>
                    </div>
                </div>
                
                <div class="form-col">
                    <div class="form-group">
                        <label for="students_absent">No. of Students Absent</label>
                        <input type="number" name="students_absent" id="students_absent" required>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="attendance_link">Attendance Sheet Link</label>
                <input type="url" name="attendance_link" id="attendance_link" placeholder="https://example.com/attendance" required>
            </div>
            
            <div class="form-group">
                <label for="notes">Additional Notes</label>
                <textarea name="notes" id="notes" rows="4"></textarea>
            </div>
            
            <button type="submit" class="submit-btn">Save Session Data</button>
        <?= form_close() ?>
    </div>

    <script>
        // Update file input display
        document.querySelectorAll('.file-input').forEach(input => {
            input.addEventListener('change', function() {
                const fileName = this.files[0]?.name || 'No file chosen';
                this.previousElementSibling.textContent = fileName;
            });
        });
    </script>
</body>
</html>
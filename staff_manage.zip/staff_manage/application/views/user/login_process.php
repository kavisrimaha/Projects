<?php
session_start();
require_once 'includes/config.php';

$username = $_POST['username'];
$password = $_POST['password'];

// Fetch user by username
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    
    // Optional: Make admin flag if username is 'admin'
    $_SESSION['is_admin'] = ($user['username'] === 'admin');

    header("Location: tracker.php");
    exit;
} else {
    header("Location: authenticate.php?error=1");
    exit;
}

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Login | CodeIgniter</title>
    <style>
        /* Base Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #FFCCB8; /* Matching registration background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        /* Container */
        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin: 20px;
        }

        /* Typography */
        h1 {
            color: #A05535; /* Primary brown color */
            text-align: center;
            margin-bottom: 25px;
            font-size: 24px;
        }

        /* Form Elements */
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #A05535;
            outline: none;
            box-shadow: 0 0 0 2px rgba(160, 85, 53, 0.2);
        }

        /* Password Wrapper */
        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            cursor: pointer;
            position: absolute;
            right: 12px;
            top: 14px;
            color: #777;
        }

        /* Buttons */
        button[type="submit"] {
            background-color: #A05535;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        button[type="submit"]:hover {
            background-color: #804225; /* Darker shade for hover */
        }

        /* Messages */
        .flash-error {
            color: #D32F2F;
            background-color: #FFEBEE;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #D32F2F;
            text-align: center;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .login-container {
                padding: 20px;
                margin: 10px;
            }
            
            h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>LOGIN</h1>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="flash-error"><?= $this->session->flashdata('error') ?></div>
        <?php endif; ?>

           <form action="<?= site_url('admin_login/authenticate') ?>" method="post">
                <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="password" required>
                    <span class="toggle-password" onclick="togglePassword()">👁️</span>
                </div>
            </div>

            <button type="submit">Login</button>
        </form>
    </div>

    <script>
        function togglePassword() {
            const pwd = document.getElementById('password');
            pwd.type = pwd.type === 'password' ? 'text' : 'password';
        }
    </script>
</body>
</html>
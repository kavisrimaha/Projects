<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>User Management | Admin Panel</title>
    <style>
        /* Same styles as your session tracker */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #A05535;
            border-bottom: 2px solid #A05535;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #A05535;
            color: white;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .action-btns a {
            padding: 5px 10px;
            margin: 0 5px;
            text-decoration: none;
            border-radius: 4px;
        }
        .edit-btn {
            background-color: #4CAF50;
            color: white;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
        }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }
        .add-user-btn {
            display: inline-block;
            background-color: #A05535;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Management</h1>
        
        <?php if($this->session->flashdata('success')): ?>
            <div style="color: green; margin-bottom: 20px;">
                <?= $this->session->flashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <?php if($this->session->flashdata('error')): ?>
            <div style="color: red; margin-bottom: 20px;">
                <?= $this->session->flashdata('error') ?>
            </div>
        <?php endif; ?>
        
        <a href="<?= site_url('/register') ?>" class="add-user-btn">Add New User</a>
        
        <table>
            <thead>
                <tr>
                    <!-- <th>ID</th> -->
                    <th>Username</th>
                    <th>Role</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $user): ?>
                <tr>
                    <!-- <td><?= $user['id'] ?></td> -->
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= ucfirst($user['role']) ?></td>
                    <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                    <td class="action-btns">
                        <a href="<?= site_url('admin/users/edit/'.$user['id']) ?>" class="edit-btn">Edit</a>
                        <a href="<?= site_url('admin/users/delete/'.$user['id']) ?>" class="delete-btn" 
                           onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="pagination">
            <?= $pagination_links ?>
        </div>
    </div>
</body>
</html>
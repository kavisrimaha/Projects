<style>
    /* Base Styles */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #FFCCB8; /* Matching registration background */
        margin: 0;
        padding: 20px;
        color: #333;
    }

    /* Container */
    .data-container {
        background-color: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 1200px;
        margin: 20px auto;
    }

    /* Typography */
    h1 {
        color: #A05535; /* Primary brown color */
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
    }

    /* DataTable Wrapper - Adds space around the table */
    .dataTables_wrapper {
        margin: 25px 0;
    }

    /* DataTable Styles */
    #sessionsTable {
        width: 100% !important;
        margin: 20px 0;
        border-collapse: separate;
        border-spacing: 0;
    }

    #sessionsTable thead th {
        background-color: #A05535;
        color: white;
        font-weight: 600;
        padding: 15px;
    }

    #sessionsTable tbody tr {
        background-color: white;
        transition: background-color 0.3s;
    }

    #sessionsTable tbody tr:hover {
        background-color: #FFE5DC;
    }

    #sessionsTable tbody td {
        padding: 12px 15px;
        border-bottom: 1px solid #FFD9C9;
    }

    /* Button Container - Adds space below buttons */
    .dt-buttons {
        margin-bottom: 25px;
    }

    /* Buttons */
    .dt-buttons .dt-button {
        background-color: #A05535 !important;
        color: white !important;
        border: none !important;
        padding: 10px 18px !important;
        border-radius: 4px !important;
        font-size: 14px !important;
        transition: background-color 0.3s !important;
        margin-right: 12px !important;
        margin-bottom: 10px !important;
    }

    .dt-buttons .dt-button:hover {
        background-color: #804225 !important;
    }

    /* Filter and Length Controls - Added spacing */
    .dataTables_filter {
        margin: 20px 0;
    }

    .dataTables_length {
        margin: 20px 0;
    }

    .dataTables_filter input {
        border: 1px solid #ddd !important;
        border-radius: 4px !important;
        padding: 8px 12px !important;
        margin-left: 10px;
    }

    .dataTables_length select {
        border: 1px solid #ddd !important;
        border-radius: 4px !important;
        padding: 6px !important;
        margin-left: 10px;
        margin-right: 10px;
    }

    /* Pagination - Added spacing */
    .dataTables_paginate {
        margin-top: 25px;
    }

    .dataTables_paginate .paginate_button {
        color: #A05535 !important;
        border: 1px solid #FFD9C9 !important;
        margin: 0 5px !important;
        padding: 6px 12px !important;
        border-radius: 4px !important;
    }

    .dataTables_paginate .paginate_button.current {
        background-color: #A05535 !important;
        color: white !important;
        border: none !important;
    }

    .dataTables_paginate .paginate_button:hover {
        background-color: #FFE5DC !important;
        color: #804225 !important;
    }

    /* Info Text - Added spacing */
    .dataTables_info {
        margin-top: 15px;
        display: block;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .data-container {
            padding: 20px;
        }
        
        h1 {
            font-size: 20px;
            margin-bottom: 20px;
        }
        
        .dt-buttons {
            margin-bottom: 15px;
        }
        
        .dataTables_filter,
        .dataTables_length {
            margin: 15px 0;
        }
        
        .dataTables_paginate {
            margin-top: 20px;
        }
    }
</style>

<div class="data-container">
    <h1>Session Attendance Records</h1>
    <table id="sessionsTable" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Hub Name</th>
                <th>Date</th>
                <th>Session Number</th>
                <th>Students Present</th>
                <th>Students Absent</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sessions as $session): ?>
            <tr>
                <td><?= $session['id'] ?></td>
                <td><?= $session['hub_name'] ?></td>
                <td><?= $session['date'] ?></td>
                <td><?= $session['session_number'] ?></td>
                <td><?= $session['students_present'] ?></td>
                <td><?= $session['students_absent'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- JavaScript at the bottom -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>

<script>
$(document).ready(function() {
    $('#sessionsTable').DataTable({
        dom: '<"top"lfB>rt<"bottom"ip>',
        buttons: [
            {
                extend: 'excel',
                text: 'Export to Excel',
                className: 'btn btn-success',
                title: 'Sessions_Export_<?= date("Y-m-d") ?>',
                exportOptions: {
                    columns: [0, 1, 2, 3, 4, 5] // Export all columns
                }
            }
        ],
        language: {
            search: "Search records:",
            lengthMenu: "Show _MENU_ records per page",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            paginate: {
                previous: "Previous",
                next: "Next"
            }
        }
    });
});
</script>
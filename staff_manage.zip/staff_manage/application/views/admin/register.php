<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        /* Base Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #FFCCB8; /* Soft peach background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        /* Container */
        .registration-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            margin: 20px;
        }

        /* Typography */
        h2 {
            color: #A05535; /* Primary brown color */
            text-align: center;
            margin-bottom: 25px;
            font-size: 24px;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #A05535;
            outline: none;
            box-shadow: 0 0 0 2px rgba(160, 85, 53, 0.2);
        }

        /* Buttons */
        button[type="submit"] {
            background-color: #A05535;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #804225; /* Darker shade for hover */
        }

        /* Messages */
        .error {
            color: #D32F2F;
            background-color: #FFEBEE;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #D32F2F;
        }

        .success {
            color: #388E3C;
            background-color: #E8F5E9;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #388E3C;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .registration-container {
                padding: 20px;
                margin: 10px;
            }
            
            h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <h2>User Registration</h2>
        
        <?php if($this->session->flashdata('error')): ?>
            <div class="error"><?= $this->session->flashdata('error') ?></div>
        <?php endif; ?>
        
        <?php if($this->session->flashdata('success')): ?>
            <div class="success"><?= $this->session->flashdata('success') ?></div>
        <?php endif; ?>
        
        <?= form_open('admin/register/submit') ?>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" value="<?= set_value('username') ?>" required>
                <?= form_error('username', '<div class="error">', '</div>') ?>
            </div>
            
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <?= form_error('password', '<div class="error">', '</div>') ?>
            </div>
            
            <div class="form-group">
                <label for="passconf">Confirm Password:</label>
                <input type="password" name="passconf" id="passconf" required>
                <?= form_error('passconf', '<div class="error">', '</div>') ?>
            </div>
            
            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        <?= form_close() ?>
    </div>
</body>
</html>
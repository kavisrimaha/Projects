<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->helper(['url', 'security']);
        $this->load->library(['session', 'form_validation']);
    }

    public function index() {
        // if ($this->session->userdata('logged_in')) {
        //     redirect('user/tracker');
        // }
        $this->load->view('user/authenticate');
    }

   public function authenticate() {
    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');
    
    if ($this->form_validation->run() === FALSE) {
        // Reload login page with errors
        $this->load->view('user/authenticate');
    } else {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->Admin_model->verify_user($username, $password);

        if ($user) {
            $this->session->set_userdata([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'] ?? 'user',
                'logged_in' => TRUE
            ]);
            
            // Redirect to tracker after successful login
            redirect('user/tracker'); // Make sure this matches your route
        } else {
            $this->session->set_flashdata('error', 'Invalid credentials');
            redirect('admin_login'); // Redirect back to login page
        }
    }
}

    public function tracker() {
        // if (!$this->session->userdata('logged_in')) {
        //     redirect('admin_login');
        // }
        
        $this->load->view('user/tracker', [
            'username' => $this->session->userdata('username')
        ]);
    }
}
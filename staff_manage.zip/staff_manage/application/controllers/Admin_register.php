<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->helper(['form', 'url', 'security']);
        $this->load->library(['session', 'form_validation']);
    }

    public function index() {
        $this->load->view('admin/register');
    }

    public function submit() {
        $this->form_validation->set_rules('username', 'Username', 'required|min_length[4]|is_unique[users.username]|trim|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');
        
        if ($this->form_validation->run() === FALSE) {
            $this->load->view('admin/register');
        } else {
            $data = [
                'username' => $this->input->post('username', TRUE),
                'password' => $this->input->post('password'),
                'role' => 'user' // Default role
            ];

            if ($this->Admin_model->register_user($data)) {
                $this->session->set_flashdata('success', 'Registration successful! Please login.');
                redirect('admin_login');
            } else {
                $this->session->set_flashdata('error', 'Registration failed. Please try again.');
                redirect('admin_register');
            }
        }
    }
}
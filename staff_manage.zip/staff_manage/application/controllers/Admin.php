<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('session_model');
        $this->load->model('Admin_model'); // Add this line
        $this->load->library('upload');
        $this->load->helper('url');
        $this->load->library('pagination'); // Add pagination library
        
        if (!$this->session->userdata('logged_in')) {
            redirect('user/authenticate');
        }
    }

    public function tracker() {
        $this->load->view('user/tracker', [
            'username' => $this->session->userdata('username')
        ]);
    }

    public function save_session() {
        // File upload configuration
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4|mov|avi';
        $config['max_size'] = 20480; // 20MB
        
        // Create upload directory if not exists
        if (!is_dir($config['upload_path'])) {
            mkdir($config['upload_path'], 0755, true);
        }

        // Upload Geo Tag
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('geo_tag')) {
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('error', $error);
            redirect('user/tracker');
        }
        $geo_tag_data = $this->upload->data();
        
        // Upload Session Video
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('session_video')) {
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('error', $error);
            redirect('user/tracker');
        }
        $video_data = $this->upload->data();

        // Prepare session data
        $session_data = [
            'hub_name' => $this->input->post('hub_name'),
            'date' => $this->input->post('date'),
            'session_number' => $this->input->post('session_number'),
            'sessions_taken' => $this->input->post('sessions_taken'),
            'expense_amount' => $this->input->post('expense_amount'),
            'geo_tag' => 'uploads/' . $geo_tag_data['file_name'],
            'session_video' => 'uploads/' . $video_data['file_name'],
            'students_present' => $this->input->post('students_present'),
            'students_absent' => $this->input->post('students_absent'),
            'attendance_link' => $this->input->post('attendance_link'),
            'notes' => $this->input->post('notes'),
            'username' => $this->session->userdata('username')
        ];

        // Save to database
        if ($this->session_model->save_session($session_data)) {
            $this->session->set_flashdata('success', 'Session data saved successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to save session data');
        }

        redirect('user/tracker');
    }

    public function sessions() {
        if (!$this->session->userdata('logged_in')) {
            redirect('user/authenticate');
        }

        $data['sessions'] = $this->session_model->get_all_sessions();
        $data['username'] = $this->session->userdata('username');
        
        $this->load->view('admin/session', $data);
    }
       
    public function users() {
        // Pagination config
        $config['base_url'] = site_url('admin/users');
        $config['total_rows'] = $this->Admin_model->count_users();
        $config['per_page'] = 10;
        $config['uri_segment'] = 3;
        
        $this->pagination->initialize($config);
        
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        
        $data = [
            'users' => $this->Admin_model->get_paginated_users($config['per_page'], $page),
            'pagination_links' => $this->pagination->create_links(),
            'username' => $this->session->userdata('username')
        ];
        
        $this->load->view('admin/users_list', $data);
    }

    public function add_user() {
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
        $this->form_validation->set_rules('role', 'Role', 'required|in_list[admin,user]');
        
        if ($this->form_validation->run()) {
            $data = [
                'username' => $this->input->post('username'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'role' => $this->input->post('role'),
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            if ($this->Admin_model->register_user($data)) {
                $this->session->set_flashdata('success', 'User added successfully');
                redirect('admin/users');
            } else {
                $this->session->set_flashdata('error', 'Failed to add user');
            }
        }
        
        $this->load->view('admin/user_form', [
            'username' => $this->session->userdata('username'),
            'action' => 'add'
        ]);
    }

    public function edit_user($id) {
        $user = $this->Admin_model->get_user($id);
        if (!$user) {
            $this->session->set_flashdata('error', 'User not found');
            redirect('admin/users');
        }
        
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('role', 'Role', 'required|in_list[admin,user]');
        
        if ($this->form_validation->run()) {
            $data = [
                'username' => $this->input->post('username'),
                'role' => $this->input->post('role')
            ];
            
            if ($this->input->post('password')) {
                $data['password'] = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
            }
            
            if ($this->Admin_model->update_user($id, $data)) {
                $this->session->set_flashdata('success', 'User updated successfully');
                redirect('admin/users');
            } else {
                $this->session->set_flashdata('error', 'Failed to update user');
            }
        }
        
        $this->load->view('admin/user_form', [
            'user' => $user,
            'username' => $this->session->userdata('username'),
            'action' => 'edit/'.$id
        ]);
    }

    public function delete_user($id) {
        if ($this->Admin_model->delete_user($id)) {
            $this->session->set_flashdata('success', 'User deleted successfully');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete user');
        }
        redirect('admin/users');
    }
}
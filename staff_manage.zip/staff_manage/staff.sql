-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2025 at 06:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staff`
--

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `hub_name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `session_number` int(11) NOT NULL,
  `sessions_taken` int(11) NOT NULL,
  `expense_amount` decimal(10,2) NOT NULL,
  `geo_tag` varchar(255) NOT NULL,
  `session_video` varchar(255) NOT NULL,
  `students_present` int(11) NOT NULL,
  `students_absent` int(11) NOT NULL,
  `attendance_link` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `hub_name`, `date`, `session_number`, `sessions_taken`, `expense_amount`, `geo_tag`, `session_video`, `students_present`, `students_absent`, `attendance_link`, `notes`, `created_at`, `username`) VALUES
(1, 'NAAN MUDHALVAN', '2025-08-01', 1, 5, 10000.00, 'uploads/banner_6889bd4bead6a.jpg', 'uploads/sample.mp4', 101, 1, 'https://example/attendance', '', '2025-08-06 17:44:19', 'admin'),
(2, 'NAAN MUDHALVAN 2', '2025-08-01', 24, 4, 444.00, 'uploads/banner_6889bd4bead6a1.jpg', 'uploads/sample2.mp4', 2311, 1, 'https://example/attendance', '', '2025-08-06 19:22:36', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'user',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '$2a$12$RiWvjPW4AvB9G88I4X5JO.AG8OzQ3x64/teJXYZUXXipuBL4qK48y', 'user', '2025-08-05 23:18:20'),
(2, 'admin2', '$2y$10$q08PhRmu80ntUbYE8b.O.OUZFoAwowcIRi9DQlUVvAPgUtOeMW5QK', 'user', '2025-08-06 16:27:20'),
(3, 'admin3', '$2y$10$NatEyhplCNWDTkm6LYK0fOvCfyKDTj2TaKi2RK0YVQFL3gpvpmcxS', 'user', '2025-08-06 16:33:20'),
(4, 'admin4', '$2y$10$tsgGuFxR/MTXpOv9uew5Ve/wujR9WOvwTTBXagm/Y9Qsjl4jmREvm', 'user', '2025-08-06 16:34:39'),
(5, 'admin6', '$2y$10$U7SrLzKBKbesB3hLVZwbmuLZdK7TFzoes4EX3Jk.8ryyHszRzbKGC', 'user', '2025-08-06 16:51:22'),
(6, 'admin7', '$2y$10$mY1pyoiQSV.eIJLxAE4TYOtvrEejBpYJvFzkFk/fCZGUDuwoPumGq', 'user', '2025-08-06 18:09:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
